import express from 'express';
import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'change-me-123';
const db = new Database(process.env.DB_PATH || path.join(__dirname, 'responses.db'));

db.exec(`CREATE TABLE IF NOT EXISTS responses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  answer TEXT NOT NULL,
  format TEXT,
  choice TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
)`);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/response', (req, res) => {
  const { answer, format, choice } = req.body || {};
  if (!answer) return res.status(400).json({ ok:false, error:'answer is required' });
  const stmt = db.prepare('INSERT INTO responses (answer, format, choice) VALUES (?, ?, ?)');
  const info = stmt.run(String(answer), format ? String(format) : null, choice ? String(choice) : null);
  res.json({ ok:true, id:info.lastInsertRowid });
});

app.get('/api/responses', (req, res) => {
  if (req.query.password !== ADMIN_PASSWORD) return res.status(401).json({ ok:false, error:'Неверный пароль' });
  const rows = db.prepare('SELECT * FROM responses ORDER BY id DESC').all();
  res.json({ ok:true, responses:rows });
});

app.get('/admin', (req,res) => res.sendFile(path.join(__dirname,'public','admin.html')));
app.get('*', (req,res) => res.sendFile(path.join(__dirname,'public','index.html')));

app.listen(PORT, () => console.log(`Invite server running on port ${PORT}`));
